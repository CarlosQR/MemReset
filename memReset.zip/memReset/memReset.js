console.log("Brue")
document.addEventListener("keyup", function(event) {
    if (event.key === '+') {
	
        var memLoop = setInterval(membeanReload,500)
		let ele = document.getElementsByClassName('single-column-layout')[0];
    ele.style.setProperty ('background-color', 'red', 'important');
    }
});



setInterval(function(){ 
	
	if(localStorage.getItem("reloaded") == "ye"){
		
		let ele = document.getElementsByClassName('single-column-layout')[0];
    ele.style.setProperty ('background-color', 'red', 'important');
	console.log("there is a ye")
		memLoop= setInterval(membeanReload,5000)
	}

	if(localStorage.getItem("reloaded") == "no"){
		
	
		
		clearInterval(memLoop)
	}

}, 1000);

function membeanReload(){
		localStorage.setItem("reloaded", "ye");
		
		window.location.reload(true)	

}
	
document.addEventListener("keyup", function(event) {
    if (event.key === '-') {
		
		window.location.reload(true)	

		localStorage.setItem("reloaded", "no");
		clearInterval(memLoop)
		
    }
});





progressBars = document.getElementsByClassName('x-progress-bar')


try{



	for (let i = 0; i < progressBars.length; i++) {
		progressBarWidth = progressBars[i].style.width;
		if( progressBarWidth  == '240px' ){ 
			window.location.reload(true)}
			if( progressBarWidth  == '241px' ){
				window.location.reload(true)}
				if( progressBarWidth  == '242px' ){
					window.location.reload(true)}
					if( progressBarWidth  == '243px' ){
						window.location.reload(true)}
						if( progressBarWidth  == '244px' ){
							window.location.reload(true)}
							if( progressBarWidth  == '245px' ){
								window.location.reload(true)}
								if( progressBarWidth  == '246px' ){
									window.location.reload(true)}
									if( progressBarWidth  == '247px') {
										window.location.reload(true)}
										if( progressBarWidth  == '248px' ){
											window.location.reload(true)}
											if( progressBarWidth  == '249px' ){
												window.location.reload(true)}
												if( progressBarWidth  == '250px' ){
													window.location.reload(true)}
	
//Por Carlos Quiñones


												}


											}catch{}
											







